(function () {
    if (!window.localStorage["sndallExtension"]) {
        window.localStorage["sndallExtension"] = JSON.stringify({ version: 3 });
        window.location.reload();
    }
})();
